<%@ include file="header.jsp" %>
<div class="card">
<h1>Checkout</h1>
<p>Choose your payment method. UPI payment is a demo flow; no real money is charged.</p>
<form method="post" id="paymentForm">
  <div style="display:flex;gap:12px;flex-wrap:wrap;margin:16px 0">
    <label class="card" style="cursor:pointer;min-width:180px"><input type="radio" name="paymentMethod" value="UPI" required onchange="showPayment('UPI')"> 📱 UPI</label>
    <label class="card" style="cursor:pointer;min-width:180px"><input type="radio" name="paymentMethod" value="CASH" required onchange="showPayment('CASH')"> 💵 Cash on Delivery</label>
  </div>

  <div id="upiBox" class="card" style="display:none">
    <h2>UPI Payment</h2>
    <label>UPI ID<br><input name="upiId" id="upiId" placeholder="example@upi" pattern="[A-Za-z0-9._-]+@[A-Za-z0-9.-]+" style="width:100%;max-width:360px"></label>
    <p>Or scan this demo QR using a UPI app:</p>
    <div id="qrWrap" style="background:#fff;padding:12px;width:220px;border:1px solid #ddd">
      <img id="qr" alt="Demo UPI QR" width="196" height="196" style="display:block" src="https://api.qrserver.com/v1/create-qr-code/?size=196x196&data=upi%3A%2F%2Fpay%3Fpa%3Ddailymart%40upi%26pn%3DMartinMart%26am%3D1.00%26cu%3DINR">
    </div>
    <small>Demo QR only — replace the UPI ID/amount with your production payment integration.</small>
  </div>

  <div id="cashBox" class="card" style="display:none"><h2>Cash on Delivery</h2><p>Pay the delivery partner in cash when your order arrives.</p></div>
  <button type="submit" style="margin-top:16px">Place Order</button>
</form>
</div>
<script>
function showPayment(method){
 document.getElementById('upiBox').style.display=method==='UPI'?'block':'none';
 document.getElementById('cashBox').style.display=method==='CASH'?'block':'none';
 document.getElementById('upiId').required=method==='UPI';
}
</script>
<%@ include file="footer.jsp" %>
