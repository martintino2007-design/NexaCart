package com.daily.dailymart.util;
import com.zaxxer.hikari.HikariDataSource; import javax.sql.DataSource; import java.sql.Connection; import java.sql.SQLException;
public final class DB { private static HikariDataSource ds; private DB(){} public static void init(String url,String user,String password){ds=new HikariDataSource();ds.setJdbcUrl(url);ds.setUsername(user);ds.setPassword(password);ds.setMaximumPoolSize(10);} public static Connection get()throws SQLException{return ds.getConnection();} public static DataSource source(){return ds;} public static void close(){if(ds!=null)ds.close();} }
