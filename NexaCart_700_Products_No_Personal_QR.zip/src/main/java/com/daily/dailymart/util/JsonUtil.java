package com.daily.dailymart.util;
import com.google.gson.Gson; import javax.servlet.http.HttpServletResponse; import java.io.IOException;
public final class JsonUtil { private static final Gson G=new Gson(); private JsonUtil(){} public static void send(HttpServletResponse r,Object o,int status)throws IOException{r.setStatus(status);r.setContentType("application/json");r.setCharacterEncoding("UTF-8");r.getWriter().write(G.toJson(o));} public static Gson gson(){return G;} }
