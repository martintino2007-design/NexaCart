package com.daily.dailymart.ai; public interface ChatProvider {String getReply(String userMessage,String context) throws Exception;}
