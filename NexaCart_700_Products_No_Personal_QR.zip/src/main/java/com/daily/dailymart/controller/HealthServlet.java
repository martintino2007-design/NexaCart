package com.daily.dailymart.controller;
import com.daily.dailymart.dto.ApiResponse; import com.daily.dailymart.util.DB; import com.daily.dailymart.util.JsonUtil; import javax.servlet.http.*; import java.sql.Connection;
public class HealthServlet extends HttpServlet {protected void doGet(HttpServletRequest r,HttpServletResponse s)throws java.io.IOException{try(Connection c=DB.get()){JsonUtil.send(s,ApiResponse.ok(java.util.Map.of("status","UP","db","UP")),200);}catch(Exception e){JsonUtil.send(s,ApiResponse.fail("DB_DOWN","Database unavailable"),503);}}}
