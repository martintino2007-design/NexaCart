package com.daily.dailymart.model;
import java.time.LocalDateTime;
public class Review { public long id,productId,userId; public int rating; public String comment; public LocalDateTime createdAt; }
