package com.daily.dailymart.model;
import java.math.BigDecimal; import java.time.LocalDateTime;
public class Product { public long id,sellerId; public String name,description,category,imageUrl; public BigDecimal price; public int stockQty; public LocalDateTime createdAt; }
