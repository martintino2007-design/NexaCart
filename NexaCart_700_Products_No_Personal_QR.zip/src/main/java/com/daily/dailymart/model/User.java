package com.daily.dailymart.model;
import java.time.LocalDateTime;
public class User { public long id; public String name,email,passwordHash,role; public LocalDateTime createdAt; }
