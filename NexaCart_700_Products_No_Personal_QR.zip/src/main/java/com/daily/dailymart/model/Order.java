package com.daily.dailymart.model;
import java.math.BigDecimal; import java.time.LocalDateTime;
public class Order { public long id,buyerId; public String status,paymentMethod,upiId; public BigDecimal totalAmount; public LocalDateTime createdAt; }
