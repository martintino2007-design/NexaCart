package com.daily.dailymart.model;
import java.math.BigDecimal;
public class OrderItem { public long id,orderId,productId; public int quantity; public BigDecimal unitPrice; }
