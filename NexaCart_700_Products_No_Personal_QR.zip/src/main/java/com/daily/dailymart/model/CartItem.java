package com.daily.dailymart.model;
import java.math.BigDecimal;
public class CartItem { public long id,userId,productId; public String productName; public BigDecimal unitPrice; public int quantity; public BigDecimal getTotal(){return unitPrice.multiply(BigDecimal.valueOf(quantity));} }
