package com.daily.dailymart.dto;
public class UserResponseDTO { public long id; public String name,email,role; }
