package com.daily.dailymart.dao.impl;
import com.daily.dailymart.dao.ReviewDAO; import com.daily.dailymart.model.Review; import com.daily.dailymart.util.DB; import java.sql.*; import java.util.*;
public class JdbcReviewDAO implements ReviewDAO { private Review map(ResultSet r)throws SQLException{Review x=new Review();x.id=r.getLong("id");x.productId=r.getLong("product_id");x.userId=r.getLong("user_id");x.rating=r.getInt("rating");x.comment=r.getString("comment");x.createdAt=r.getTimestamp("created_at").toLocalDateTime();return x;}
 public void create(Review r)throws SQLException{String q="INSERT INTO reviews(product_id,user_id,rating,comment) VALUES(?,?,?,?)";try(Connection c=DB.get();PreparedStatement p=c.prepareStatement(q)){p.setLong(1,r.productId);p.setLong(2,r.userId);p.setInt(3,r.rating);p.setString(4,r.comment);p.executeUpdate();}}
 public List<Review> findByProduct(long pid)throws SQLException{try(Connection c=DB.get();PreparedStatement p=c.prepareStatement("SELECT * FROM reviews WHERE product_id=? ORDER BY id DESC")){p.setLong(1,pid);try(ResultSet r=p.executeQuery()){List<Review> out=new ArrayList<>();while(r.next())out.add(map(r));return out;}}}
}
