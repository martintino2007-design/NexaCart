package com.daily.dailymart.dao;
import com.daily.dailymart.model.User; import java.sql.SQLException; import java.util.List;
public interface UserDAO { User findByEmail(String email)throws SQLException; User findById(long id)throws SQLException; long create(User u)throws SQLException; List<User> findAll()throws SQLException; }
