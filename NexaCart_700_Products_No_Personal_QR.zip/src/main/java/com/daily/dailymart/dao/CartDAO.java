package com.daily.dailymart.dao;
import com.daily.dailymart.model.CartItem; import java.sql.SQLException; import java.util.List;
public interface CartDAO { List<CartItem> findByUser(long userId)throws SQLException; void add(long userId,long productId,int qty)throws SQLException; void update(long userId,long productId,int qty)throws SQLException; void remove(long userId,long productId)throws SQLException; void clear(long userId)throws SQLException; }
