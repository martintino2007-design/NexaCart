package com.daily.dailymart.dao;
import com.daily.dailymart.model.Review; import java.sql.SQLException; import java.util.List;
public interface ReviewDAO { void create(Review r)throws SQLException; List<Review> findByProduct(long productId)throws SQLException; }
