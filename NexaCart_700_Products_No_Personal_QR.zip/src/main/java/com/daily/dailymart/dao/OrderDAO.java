package com.daily.dailymart.dao;
import com.daily.dailymart.model.*; import java.sql.SQLException; import java.util.List;
public interface OrderDAO { long create(Order o,List<CartItem> items)throws SQLException; List<Order> findByBuyer(long buyerId)throws SQLException; List<Order> findAll()throws SQLException; List<Order> findForSeller(long sellerId)throws SQLException; void updateStatus(long id,String status)throws SQLException; boolean canReview(long buyerId,long productId)throws SQLException; }
