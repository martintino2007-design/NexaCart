package com.daily.dailymart.dao;
import com.daily.dailymart.model.Product; import java.sql.SQLException; import java.util.List;
public interface ProductDAO { List<Product> search(String keyword,String category)throws SQLException; Product findById(long id)throws SQLException; long create(Product p)throws SQLException; void update(Product p)throws SQLException; void delete(long id,long sellerId)throws SQLException; List<Product> findBySeller(long sellerId)throws SQLException; List<Product> findAll()throws SQLException; void deleteByAdmin(long id)throws SQLException; }
