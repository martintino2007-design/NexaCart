package com.daily.dailymart.listener;
import com.daily.dailymart.util.DB; import org.slf4j.Logger; import org.slf4j.LoggerFactory; import javax.servlet.*; import java.io.*; import java.nio.charset.StandardCharsets; import java.sql.*; import java.util.*;
public class DataSourceListener implements ServletContextListener { private static final Logger log=LoggerFactory.getLogger(DataSourceListener.class);
 public void contextInitialized(ServletContextEvent e){try{Properties p=new Properties();try(InputStream in=e.getServletContext().getResourceAsStream("/WEB-INF/classes/config.properties")){if(in!=null)p.load(in);}String url=env("DB_URL",p.getProperty("db.url","jdbc:h2:./data/dailymart"));String user=env("DB_USER",p.getProperty("db.user","sa"));String pass=env("DB_PASSWORD",p.getProperty("db.password",""));DB.init(url,user,pass);runSql(e.getServletContext(),"/db/schema.sql");runSql(e.getServletContext(),"/db/seed.sql");log.info("DailyMart datasource initialized");}catch(Exception ex){throw new RuntimeException("Database initialization failed",ex);}}
 private String env(String k,String d){String v=System.getenv(k);return v==null||v.isBlank()?d:v;}
 private void runSql(ServletContext c,String path)throws Exception{try(InputStream in=c.getResourceAsStream(path)){if(in==null)return;String s=new String(in.readAllBytes(),StandardCharsets.UTF_8);try(Connection cn=DB.get();Statement st=cn.createStatement()){for(String part:s.split(";")){String q=part.trim();if(!q.isEmpty())st.execute(q);}}}}
 public void contextDestroyed(ServletContextEvent e){DB.close();}
}
