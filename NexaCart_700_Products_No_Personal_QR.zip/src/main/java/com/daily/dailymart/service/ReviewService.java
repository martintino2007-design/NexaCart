package com.daily.dailymart.service;
import com.daily.dailymart.dao.ReviewDAO; import com.daily.dailymart.model.Review; import java.sql.SQLException; import java.util.List;
public class ReviewService {private final ReviewDAO dao;public ReviewService(ReviewDAO d){dao=d;}public void create(Review r)throws SQLException{if(r.rating<1||r.rating>5)throw new IllegalArgumentException("Rating must be 1-5");dao.create(r);}public List<Review> list(long p)throws SQLException{return dao.findByProduct(p);}}
