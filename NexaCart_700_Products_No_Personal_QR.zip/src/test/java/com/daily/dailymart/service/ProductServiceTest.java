package com.daily.dailymart.service;
import com.daily.dailymart.dao.ProductDAO; import com.daily.dailymart.model.Product; import org.junit.jupiter.api.Test; import java.math.BigDecimal; import static org.junit.jupiter.api.Assertions.*; import static org.mockito.Mockito.*;
class ProductServiceTest { @Test void rejectsNegativePrice() throws Exception {ProductDAO dao=mock(ProductDAO.class);Product p=new Product();p.name="x";p.category="c";p.price=BigDecimal.valueOf(-1);p.stockQty=1;assertThrows(IllegalArgumentException.class,()->new ProductService(dao).create(p));verifyNoInteractions(dao);} }
