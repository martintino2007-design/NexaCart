MERGE INTO users (id,name,email,password_hash,role) KEY(id) VALUES
(1,'MartinMart Admin','admin@MartinMart.local','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','ADMIN'),
(2,'Demo Seller','seller@MartinMart.local','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','SELLER'),
(3,'Demo Buyer','buyer@MartinMart.local','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','BUYER');
MERGE INTO products (id,seller_id,name,description,price,stock_qty,category,image_url) KEY(id) VALUES
(1,2,'Premium Basmati Rice','5 kg premium rice pack',499.00,40,'Groceries','https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=900&q=85'),
(2,2,'Organic Sugar','1 kg organic cane sugar',79.00,60,'Groceries','https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85'),
(3,2,'Wireless Mouse','Ergonomic wireless mouse',699.00,25,'Electronics','https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=85'),
(4,2,'Notebook Set','Set of 3 ruled notebooks',149.00,80,'Stationery','https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=900&q=85');
